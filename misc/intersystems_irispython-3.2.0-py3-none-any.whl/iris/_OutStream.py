import iris._BufferWriter
import iris._LogFileStream

class _OutStream(object):

	def __init__(self, connection):
		self._connection = connection
		self._device = connection._device
		self._log_stream = connection._log_stream
		self.wire = iris._BufferWriter(self._connection._connection_info._locale,self._connection._connection_info._is_unicode)

	def _send(self, sequence_number):
		list_len = self.wire._size()
		self.wire.header._set_message_length(list_len)
		self.wire.header._set_count(sequence_number)
		if self._device is None:
			raise RuntimeError("no longer connected to server")
		self._device.sendall(self.wire.header.buffer) #self._device._socket.sendall(self.wire.header.buffer)
		if self._log_stream is not None:
			self._log_stream._dump_header(self.wire.header.buffer, iris._LogFileStream.LOG_SENT)
		if list_len > 0:
			self._device.sendall(self.wire._get_buffer()) #self._device._socket.sendall(self.wire._get_buffer())
			if self._log_stream is not None:
				self._log_stream._dump_message(self.wire._get_buffer())
		return

