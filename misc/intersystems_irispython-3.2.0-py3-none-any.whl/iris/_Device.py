import base64
import getpass
import os
import platform
import socket
import struct
import sys
import threading
import iris._SharedMemorySocket

class _Device(object):

	def __init__(self, _socket):
		if _socket is None:
			self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		else:
			self._socket = _socket

	def close(self):
		return self._socket.close()

	def settimeout(self,time):
		return self._socket.settimeout(time)

	def connect(self, server_address):
		return self._socket.connect(server_address)

	def sendall(self, buff):
		return self._socket.sendall(buff)

	def recv(self, len):
		return self._socket.recv(len)

	def gethostname(self):
		return socket.gethostname()

	def gethostbyname(self, hostname):
		return socket.gethostbyname(hostname)

	def establishSHMSocket(self,iris_bin_dir, server_job_number):
		shmSocket = iris._SharedMemorySocket._SharedMemorySocket(iris_bin_dir, server_job_number, "", 0)
		shmSocket.connect(10)
		#close TCP/IP socket
		self._socket.close()
		#Assign SharedMemorySocket to socket
		self._socket = shmSocket