class IRISReference(object):
	'''
Used to call method/routine for pass-by-reference arguments

iris.IRISReference(value, type)

Parameters
----------
type : Python type used as a type hint for unmarshaling modified value of the argument. Supported types are  bool, bytes, bytearray, Decimal, float, int, str or IRISList. if none is specified, Python Gateway uses the type that matches the original IRIS type.
'''

	def __init__(self, value, type = object):
		self._value = value
		self._type = type

	def __str__(self):
		return "<iris.%s object at 0x%.16X>" % (self.__class__.__name__, id(self))

	def get_value(self):
		'''Return the value of the argument'''
		return self._value

	def set_value(self, value):
		'''Set the data of the argument'''
		self._value = value
		return

	def get_type(self):
		'''Return the type hint of the argument'''
		return self._type

	def set_type(self, type):
		'''Set the type hint of the argument'''
		self._type = type
		return
