class _MessageHeader(object):
    
	HEADER_SIZE = 14

	def __init__(self):
		self.buffer = bytearray(_MessageHeader.HEADER_SIZE)

	def _get_message_length(self):
		return self.__get_4_byte_int_raw(0)

	def _get_message_id(self):
		return self.__get_4_byte_int_raw(4)

	# TODO: remove this method, use _get_message_id()
	def _get_count(self):
		return self.__get_4_byte_int_raw(4)

	def _get_function_code(self):
		return (self.buffer[12] & 0x00FF) | ((self.buffer[13] & 0x00FF) << 8)

	# TODO: remove this method, use _get_function_code()
	def _get_error(self):
		return (self.buffer[12] & 0x00FF) | ((self.buffer[13] & 0x00FF) << 8)

	def _set_count(self, value):
		self.__set_raw_4_byte_int(4, value)

	def _set_message_length(self, value):
		self.__set_raw_4_byte_int(0, value)

	def __get_4_byte_int_raw(self, offset):
		return ((self.buffer[offset] & 0x000000FF) | 
		  ((self.buffer[offset + 1] & 0x000000FF) << 8) |
		  ((self.buffer[offset + 2] & 0x000000FF) << 16) | 
		  ((self.buffer[offset + 3] & 0x000000FF) << 24))

	def __set_raw_4_byte_int(self, offset, value):
		self.buffer[offset] = value & 0xFF
		self.buffer[offset + 1] = (value >> 8) & 0xFF
		self.buffer[offset + 2] = (value >> 16) & 0xFF
		self.buffer[offset + 3] = (value >> 24) & 0xFF
